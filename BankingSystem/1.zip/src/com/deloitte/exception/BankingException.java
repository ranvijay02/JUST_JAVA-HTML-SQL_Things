package com.deloitte.exception;

public class BankingException extends Exception {

	public BankingException(String message) {
		super(message);
	}

}
